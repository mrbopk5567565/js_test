const quoteTextEl = document.querySelector('.quotes__text');
console.log('quoteTextEl', quoteTextEl.textContent);
