/* © 2016 NauStud.io
 * @author Thanh
 */

console.log('\'Allo \'Allo! Option');
